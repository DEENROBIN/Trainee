from odoo import models, fields

class StudentClass(models.Model):
    _name = 'student.class'
    _description = 'Student Class'

    name = fields.Char(string='Class Name', required=True)
