# -*- coding: utf-8 -*-

from . import student_class
from . import student_section
from . import student_institute
