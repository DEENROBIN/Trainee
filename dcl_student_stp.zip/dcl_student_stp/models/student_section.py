from odoo import models, fields

class StudentSection(models.Model):
    _name = 'student.section'
    _description = 'Student Section'

    name = fields.Char(string='Section Name', required=True)
